<?php
// Bailout, if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Define plugin version in SemVer format.
if ( ! defined( 'MPAISA4WC_VERSION' ) ) {
	define( 'MPAISA4WC_VERSION', '1.0.0' );
}

// Define plugin root File.
if ( ! defined( 'MPAISA4WC_PLUGIN_FILE' ) ) {
	define( 'MPAISA4WC_PLUGIN_FILE', dirname( dirname( __FILE__ ) ) . '/mpaisa-for-woocommerce.php' );
}

// Define plugin basename.
if ( ! defined( 'MPAISA4WC_PLUGIN_BASENAME' ) ) {
	define( 'MPAISA4WC_PLUGIN_BASENAME', plugin_basename( MPAISA4WC_PLUGIN_FILE ) );
}

// Define plugin directory Path.
if ( ! defined( 'MPAISA4WC_PLUGIN_DIR' ) ) {
	define( 'MPAISA4WC_PLUGIN_DIR', plugin_dir_path( MPAISA4WC_PLUGIN_FILE ) );
}

// Define plugin directory URL.
if ( ! defined( 'MPAISA4WC_PLUGIN_URL' ) ) {
	define( 'MPAISA4WC_PLUGIN_URL', plugin_dir_url( MPAISA4WC_PLUGIN_FILE ) );
}
