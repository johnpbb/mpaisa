
To upload the plugin files, you need to login to WordPress admin and then follow the steps below:
1. Click on Plugins
2. Click on "Upload Plugin" at the top left which will open a section to upload the file
3. After adding the plugin ZIP file to the uploader, click Upload
4. Plugin will get installed.
5. Find the plugin name "Mpaisa for WooCommerce" and then click Activate


For WooCommerce, after activating, you can find settings under WooCommerce > Settings > Payments > Mpaisa