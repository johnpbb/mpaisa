<?php
/**
 * mPaisa for WooCommerce | Admin Actions
 *
 * @since 1.0.0
 */

namespace mPaisa\WC\Admin;

use WC_Admin_Settings;

// Bailout, if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Actions {
	/**
	 * Constructor.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @return void
	 */
	public function __construct() {
	}
}
