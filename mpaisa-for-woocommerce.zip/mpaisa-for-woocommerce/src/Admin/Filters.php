<?php
/**
 * mPaisa for WooCommerce | Admin Filters.
 *
 * @since 1.0.0
 */

namespace mPaisa\WC\Admin;

// Bailout, if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Filters {
	/**
	 * Constructor.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @return void
	 */
	public function __construct() {
		add_filter( 'plugin_action_links_' . MPAISA4WC_PLUGIN_BASENAME, [ $this, 'add_plugin_actions' ] );
	}

	/**
	 * Add Plugin Actions.
	 *
	 * @param array $links Plugin Action Links.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @return void
	 */
	public function add_plugin_actions( $links ) {
		$action_links['settings'] = sprintf(
			'<a href="%1$s">%2$s</a>',
			admin_url( 'admin.php?page=wc-settings&tab=checkout&section=mpaisa' ),
			esc_html__( 'Settings', 'mpaisa-for-woocommerce' )
		);

		return array_merge( $action_links, $links );
	}
}
