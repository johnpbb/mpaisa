<?php
/**
 * mPaisa for WooCommerce | Checkout
 *
 * @since 1.0.0
 */

namespace mPaisa\WC\Includes\PaymentMethods;

use Error;
use mPaisa\WC\Includes\Helpers as Helpers;

// Bailout, if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Mpaisa extends \WC_Payment_Gateway {

	public $testmode;
	public $client_id;
	public $client_secret;
	/**
	 * Constructor.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @return void
	 */
	public function __construct() {
		$this->id                 = 'mpaisa';
		// $this->icon               = AP4WC_PLUGIN_URL . 'assets/dist/images/unionpay-logo.png';
		$this->has_fields         = false;
		$this->method_title       = esc_html__( 'mPaisa Checkout', 'mpaisa-for-woocommerce' );
		$this->method_description = esc_html__( 'Checkout payment method of mPaisa payment gateway.', 'mpaisa-for-woocommerce' );

		// gateways can support subscriptions, refunds, saved payment methods,
		// but in this tutorial we begin with simple payments.
		$this->supports = [
			'products',
			'refunds',
		];

		// Method with all the options fields.
		$this->init_form_fields();

		$this->title         = $this->get_option( 'title' );
		$this->description   = $this->get_option( 'description' );
		$this->enabled       = $this->get_option( 'enabled' );
		$this->testmode      = 'yes' === $this->get_option( 'testmode' );
		$this->client_id     = $this->testmode ? $this->get_option( 'test_client_id' ) : $this->get_option( 'client_id' );
		$this->client_secret = $this->testmode ? $this->get_option( 'test_client_secret' ) : $this->get_option( 'client_secret' );
		$this->request_url   = $this->testmode ? 'https://pay.mpaisa.vodafone.com.fj' : 'https://pay.mpaisa.vodafone.com.fj/live';
		$this->checkout_url  = wc_get_checkout_url();

		// This action hook saves the settings
		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, [ $this, 'process_admin_options' ] );

		// For payment verification.
		add_action( "wp_ajax_mpaisa_verify_payment", [ $this, 'verify_payment' ] );
		add_action( "wp_ajax_nopriv_mpaisa_verify_payment", [ $this, 'verify_payment' ] );

		// Load the redirect to checkout page and listen module only on checkout page.
		if ( is_checkout() ) {
			$this->redirect_to_checkout_page();
		}

	}

	/**
	 * Admin Settings Fields.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @return void
	 */
	public function init_form_fields() {
		$this->form_fields = [
			'enabled'            => [
				'title'       => esc_html__( 'Enable/Disable', 'mpaisa-for-woocommerce' ),
				'label'       => esc_html__( 'Enable - Checkout with mPaisa', 'mpaisa-for-woocommerce' ),
				'type'        => 'checkbox',
				'description' => '',
				'default'     => 'no',
			],
			'title'              => [
				'title'       => esc_html__( 'Title', 'mpaisa-for-woocommerce' ),
				'type'        => 'text',
				'description' => esc_html__( 'This controls the title which the user sees during checkout.', 'mpaisa-for-woocommerce' ),
				'default'     => esc_html__( 'mPaisa', 'mpaisa-for-woocommerce' ),
				'desc_tip'    => true,
			],
			'description'        => [
				'title'       => esc_html__( 'Description', 'mpaisa-for-woocommerce' ),
				'type'        => 'textarea',
				'description' => esc_html__( 'This controls the description which the user sees during checkout.', 'mpaisa-for-woocommerce' ),
				'default'     => esc_html__( 'Pay with your credit card via our mPaisa payment gateway. You will be redirected to mPaisa checkout page.', 'mpaisa-for-woocommerce' ),
			],
			'testmode'           => [
				'title'       => esc_html__( 'Test mode', 'mpaisa-for-woocommerce' ),
				'label'       => esc_html__( 'Enable Test Mode', 'mpaisa-for-woocommerce' ),
				'type'        => 'checkbox',
				'description' => esc_html__( 'Place the payment gateway in test mode using test API keys.', 'mpaisa-for-woocommerce' ),
				'default'     => 'yes',
				'desc_tip'    => true,
			],
			'test_client_id'   => [
				'title'       => esc_html__( 'Test - Client ID', 'mpaisa-for-woocommerce' ),
				'type'        => 'text',
				'description' => esc_html__( 'Test Client ID assigned by mPaisa payment gateway.', 'mpaisa-for-woocommerce' ),
				'default'     => '',
				'desc_tip'    => true,
			],
			'test_client_secret' => [
				'title'       => esc_html__( 'Test - Client Secret', 'mpaisa-for-woocommerce' ),
				'type'        => 'text',
				'description' => esc_html__( 'Test Client Secret assigned by mPaisa payment gateway.', 'mpaisa-for-woocommerce' ),
				'default'     => '',
				'desc_tip'    => true,
			],
			'client_id'        => [
				'title'       => esc_html__( 'Client ID', 'mpaisa-for-woocommerce' ),
				'type'        => 'text',
				'description' => esc_html__( 'Client ID assigned by mPaisa payment gateway.', 'mpaisa-for-woocommerce' ),
				'default'     => '',
				'desc_tip'    => true,
			],
			'client_secret'      => [
				'title'       => esc_html__( 'Client Secret', 'mpaisa-for-woocommerce' ),
				'type'        => 'text',
				'description' => esc_html__( 'Client Secret assigned by mPaisa payment gateway.', 'mpaisa-for-woocommerce' ),
				'default'     => '',
				'desc_tip'    => true,
			],
		];
	}

	/**
	 * Process Payment.
	 *
	 * @param int $order_id Order ID.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @return void
	 */
	public function process_payment( $order_id ) {
		$order = new \WC_Order( $order_id );
		$order->update_status( 'pending', esc_html__( 'Awaiting payment using mPaisa Checkout', 'mpaisa-for-woocommerce' ) );

		return [
			'result'   => 'success',
			'redirect' => add_query_arg(
				[
					'processing' => 'mpaisa',
					'id'         => $order_id,
				],
				$this->checkout_url
			),
		];
	}

	/**
	 * Redirect to Checkout page.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @return void
	 */
	public function redirect_to_checkout_page() {
		$get_data = wc_clean( $_GET );

		if (
			! empty( $get_data['processing'] ) &&
			'mpaisa' === $get_data['processing']
		) {
			Helpers::redirect_to_checkout(
				[
					'request_url'   => $this->request_url,
					'client_id'     => $this->client_id,
					'client_secret' => $this->client_secret,
				]
			);
		}
	}

	public function verify_payment() {
		global $woocommerce;

		$post_data = wc_clean( $_POST );
		$order_id  = ! empty( $post_data['orderId'] ) ? $post_data['orderId'] : '';
		$order     = wc_get_order( $order_id );

error_log( print_r( $post_data, true ) );
		// Mark Order Complete.
		$order->payment_complete( $order_id );

		// Reduce Stock Levels.
		wc_reduce_stock_levels( $order_id );

		// Add Order Note.
		$order->add_order_note( 'Payment received for the order.', true );

		// Empty cart.
		$woocommerce->cart->empty_cart();

		wp_send_json_success(
			[
				'redirect_url' => $order->get_checkout_order_received_url(),
			]
		);

	}

}
