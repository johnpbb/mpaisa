<?php
/**
 * mPaisa for WooCommerce | Frontend Filters
 *
 * @since 1.0.0
 */

namespace mPaisa\WC\Includes;

use mPaisa\WC\Includes\PaymentMethods as PaymentMethods;

// Bailout, if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Filters {
	/**
	 * Constructor.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @return void
	 */
	public function __construct() {
		add_filter( 'woocommerce_payment_gateways', [ $this, 'register_gateways' ] );
	}

	/**
	 * Register Gateways.
	 *
	 * @param array $gateways List of gateways.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @return array
	 */
	public function register_gateways( $gateways ) {
		$gateways[] = PaymentMethods\Mpaisa::class;

		return $gateways;
	}

}
