<?php
/**
 * mPaisa for WooCommerce | Frontend Actions
 *
 * @since 1.0.0
 */

namespace mPaisa\WC\Includes;

use mPaisa\WC\Includes\Helpers as Helpers;

// Bailout, if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Actions {
	/**
	 * Constructor.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @return void
	 */
	public function __construct() {
		// add_action( 'init', [ $this, 'listen' ] );
		add_action( 'wp_enqueue_scripts', [ $this, 'register_assets' ] );
		add_action( 'wp_ajax_mpaisa_verify_payment', [ $this, 'verify_mpaisa_payment' ] );
		add_action( 'wp_ajax_nopriv_mpaisa_verify_payment', [ $this, 'verify_mpaisa_payment' ] );
		add_action( 'init', [ $this, 'listen_to_backend' ] );
	}

	/**
	 * Listen to the notification from mPaisa payment gateway.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @return void
	 */
	public function listen() {
		$post_data = wc_clean( $_POST );

		// Bailout, if signature doesn't exist in response.
		if (
			! isset( $post_data['signature'] ) ||
			empty( $post_data['signature'] )
		) {
			return;
		}

		// Prepare some necessary variables.
		$signature      = $post_data['signature'];
		$transaction_id = $post_data['queryId'];
		$responseCode   = $post_data['respCode'];
		$order_id       = ltrim( $post_data['orderId'] );

		// Get Order Details.
		$order = new \WC_Order( $order_id );

		if ( '00' === $responseCode ) {
			// Payment is Complete here.
			$order->payment_complete( $transaction_id );
		} else {
			// Update order status to failed.
			$order->update_status( 'failed', esc_html__( 'Processing payment failed', 'mpaisa-for-woocommerce' ) );
		}

		return 'ok';
	}


	/**
	 * Register Assets.
	 *
	 * @since  1.1.0
	 * @access public
	 *
	 * @return void
	 */
	public function register_assets() {
		// wp_enqueue_style( 'mpaisa-for-woocommerce', MPAISA4WC_PLUGIN_URL . 'assets/dist/css/mpaisa-for-woocommerce.css' );
		// wp_enqueue_script( 'mpaisa-for-woocommerce', MPAISA4WC_PLUGIN_URL . 'assets/dist/js/mpaisa-for-woocommerce.js' );
	}

	/**
	 * Listen to backend to verify payment.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function listen_to_backend() {
		global $woocommerce;

		$post_data = wc_clean( $_POST );
		$get_data  = wc_clean( $_GET );

		// Bailout, if verify payment parameter doesn't exists on return.
		if (
			! isset( $get_data['verify_payment'] ) ||
			(
				! empty( $get_data['verify_payment'] ) &&
				'mpaisa' !== $get_data['verify_payment']
			)
		) {
			return;
		}

		// Bailout, if `tID` doesn't exist.
		if (
			! isset( $post_data['tID'] ) ||
			(
				isset( $post_data['tID'] ) &&
				empty( $post_data['tID'] )
			)
		) {
			return;
		}

		$tid      = $post_data['tID'];
		$order_id = get_transient( 'order_id_' . $tid );



		$order = new \WC_Order( $order_id );
		// $transaction_id = $order->get_meta( 'unique_transaction_id', true );

		$request_id = $post_data['rID'];
		$token      = $post_data['token'];
		$tokenv2    = $post_data['tokenv2'];
		$phone_used = $post_data['customerphonenumber'];

		$mpaisa   = new \mPaisa\WC\Includes\PaymentMethods\Mpaisa();
		$url      = $mpaisa->testmode ? 'https://pay.mpaisa.vodafone.com.fj' : 'https://pay.mpaisa.vodafone.com.fj/live';
		$response = wp_remote_get(
			$url . '/requeststatus',
			[
				'body' => [
					'rID' => $request_id,
					'tID' => $tid,
					'cID' => $mpaisa->client_id,
				],
			]
		);

		$response_body = json_decode( wp_remote_retrieve_body( $response ) );
		$response_code = wp_remote_retrieve_response_code( $response );

		// Success. Send donor to hosted checkout page.
		if (
			200 === $response_code &&
			101 === $response_body->responsecode // 101 = SUCCESS
		) {
			// Mark Order Complete.
			$order->payment_complete( $order_id );

			// Reduce Stock Levels.
			wc_reduce_stock_levels( $order_id );

			// Add Order Note.
			$order->add_order_note( 'Payment received for the order.', true );

			// Empty cart.
			$woocommerce->cart->empty_cart();

			// Redirect to order page
			wp_redirect( $order->get_checkout_order_received_url() );
			exit;
		} else {
			// Add Order Note.
			$order->add_order_note( 'Unable to verify the payment for this order.', true );

			wp_redirect( wc_get_checkout_url() );
			exit;
		}
	}
}
