<?php
/**
 * mPaisa Payment Gateway for WooCommerce | Helpers
 *
 * @since 1.0.0
 */

namespace mPaisa\WC\Includes;

// Bailout, if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Helpers {
	/**
	 * Redirect to Checkout.
	 *
	 * @param array $args List of essential arguments.
	 *
	 * @since  1.0.0
	 * @access public
	 *
	 * @return void
	 */
	public static function redirect_to_checkout( $args ) {
		// Sanitize the super global variables.
		$get_data = wc_clean( $_GET );

		// Prepare the arguments.
		$client_id     = ! empty( $args['client_id'] ) ? $args['client_id'] : '';
		$client_secret = ! empty( $args['client_secret'] ) ? $args['client_secret'] : '';
		$request_url   = ! empty( $args['request_url'] ) ? $args['request_url'] : '';
		$checkout_url  = site_url() . '?verify_payment=mpaisa'; //wc_get_checkout_url() . '?verify_payment=mpaisa';
		$currency      = ! empty( $args['currency'] ) ? $args['currency'] : 'USD';

		// Prepare Order Data.
		$order_id          = ! empty( $get_data['id'] ) ? $get_data['id'] : 0;
		$order             = new \WC_Order( $order_id );
		$amount            = $order->get_total();
		$order_description = Helpers::get_order_description( $order_id );
		$tid               = substr( crc32(uniqid( $order_id ) ), 0, 8); // Randomly added prefix to make it work.

		// Temporarily set transient to ensure that we can process the transaction successfully.
		set_transient( 'order_id_' . $tid, $order_id, HOUR_IN_SECONDS );

		$body_args       = [
			'tID'  => $tid,
			'amt'  => $amount,
			'cID'  => $client_id,
			'url'  => $checkout_url,
			'iDet' => $order_description,
		];

		// Safely call remote post.
		$response = wp_safe_remote_post(
			"{$request_url}/API/",
			[
				'headers' => [
					'Content-Type' => 'application/x-www-form-urlencoded',
				],
				'body'    => $body_args,
			]
		);

		// Get response body and code.
		$response_body = json_decode( wp_remote_retrieve_body( $response ) );
		$response_code = wp_remote_retrieve_response_code( $response );

		// Bailout, if response doesn't exists.
		if ( ! isset( $response_body->response ) ) {
			return;
		}

		$generated_sha = hash( 'sha256', "{$tid}{$amount}{$order_description}{$client_secret}{$response_body->response}" );

		// Success. Send donor to hosted checkout page.
		if (
			200 === $response_code &&
			! empty( $response_body->tokenv2 ) && strtolower( $response_body->tokenv2 ) === $generated_sha &&
			$response_body->requestID > 0
		) {
			$action_url = $response_body->destinationurl;
			$field_args = [
				'tID'  => $tid,
				'amt'  => $amount,
				'cID'  => $client_id,
				'url'  => $checkout_url,
				'iDet' => $order_description,
				'rID'  => $response_body->requestID,
			];
			?>
			<div id="mpaisa-for-woocommerce-checkout-processing-wrap">
				<div id="mpaisa-for-woocommerce-checkout-processing"></div>
				<form id="mpaisa-for-woocommerce-form" method="post" target="_top" action="<?php echo $action_url; ?>">
					<?php
					foreach ( $field_args as $name => $value ) {
						?>
						<input type="hidden" name="<?php echo $name; ?>" value="<?php echo $value; ?>"/>
						<?php
					}
					?>
				</form>
			</div>
			<script>
				// Show Processing Donation Overlay.
				const processingHtml = document.querySelector( '#mpaisa-for-woocommerce-checkout-processing');

				processingHtml.setAttribute( 'class', 'mpaisa-checkout-process' );
				processingHtml.style.background = '#FFFFFF';
				processingHtml.style.opacity = '0.9';
				processingHtml.style.position = 'fixed';
				processingHtml.style.top = '0';
				processingHtml.style.left = '0';
				processingHtml.style.bottom = '0';
				processingHtml.style.right = '0';
				processingHtml.style.zIndex = '2147483646';
				processingHtml.innerHTML = '<div class="mpaisa-for-woocommerce-checkout-processing-container" style="position: absolute;top: 50%;left: 50%;width: 300px; margin-left: -150px; text-align:center;"><div style="display:inline-block;"><span class="give-loading-animation" style="color: #333;height:26px;width:26px;font-size:26px; margin:0; "></span><span style="color:#000; font-size: 26px; margin:0 0 0 10px;"><?php echo esc_html__( 'Processing Payment...', 'mpaisa-for-woocommerce'  );?></span></div></div>';

				window.addEventListener( 'load', function() {
					document.getElementById( 'mpaisa-for-woocommerce-form' ).submit();
				});
			</script>
			<?php
		}
	}

	/**
	 * Get Order Description.
	 *
	 * @param int $order_id Order ID.
	 *
	 * @since  1.1.0
	 * @access public
	 *
	 * @return string
	 */
	public static function get_order_description( $order_id ) {
		return sprintf(
			'%1$s%2$s',
			'OrderID', // Don't need translation as it is sent to payment gateway.
			$order_id
		);
	}
}
